#!/usr/bin/env python3
import argparse, json, math, hashlib
from collections import defaultdict, Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Any, Tuple

import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_recall_fscore_support

FEATURES = [
    'piece_count','piece_types','total_area_ratio','lower_bound','max_repetition',
    'distinct_widths','distinct_heights','avg_aspect_ratio','thin_piece_ratio',
    'long_piece_ratio','directional','grain_confidence','stock_aspect_ratio'
]


def ceil_div(a,b): return int(math.ceil(a/b)) if b else 0

def case_features(c: Dict[str,Any]) -> Dict[str,float]:
    sw, sh = float(c['stock_width']), float(c['stock_height'])
    saw = float(c.get('saw') or 0)
    pieces = c.get('pieces',[])
    total_area = 0.0
    reps=[]; widths=set(); heights=set(); aspects=[]; thin=0; longp=0; count=0
    min_dim = min(sw,sh); max_dim=max(sw,sh)
    for p in pieces:
        b=float(p['base']); h=float(p['altura']); q=int(p['cant'])
        total_area += b*h*q; count += q; reps.append(q); widths.add(round(b,3)); heights.add(round(h,3))
        aspects.extend([max(b,h)/max(1.0,min(b,h))]*q)
        if min(b,h) <= 0.12*min_dim: thin += q
        if max(b,h) >= 0.65*max_dim: longp += q
    usable_area=max(1.0,(sw)*(sh))
    lb=max(1,ceil_div(total_area, usable_area)) if count else 0
    return {
        'piece_count': float(count),
        'piece_types': float(len(pieces)),
        'total_area_ratio': total_area/usable_area,
        'lower_bound': float(lb),
        'max_repetition': float(max(reps) if reps else 0),
        'distinct_widths': float(len(widths)),
        'distinct_heights': float(len(heights)),
        'avg_aspect_ratio': float(sum(aspects)/len(aspects) if aspects else 0),
        'thin_piece_ratio': float(thin/max(1,count)),
        'long_piece_ratio': float(longp/max(1,count)),
        'directional': float(bool(c.get('directional'))),
        'grain_confidence': float(c.get('grain_confidence') or 0),
        'stock_aspect_ratio': max(sw,sh)/max(1.0,min(sw,sh)),
    }

def hard_label(c):
    f=case_features(c)
    return int(int(c.get('reference_panels') or 0) > int(f['lower_bound']))


def build_memories(train):
    exact={}
    structural=defaultdict(list)
    ratio=defaultdict(list)
    for c in train:
        f=case_features(c); y=hard_label(c)
        rec={
            'case_id': c['case_id'], 'reference_panels': int(c.get('reference_panels') or 0),
            'hard': y, 'features': f,
        }
        exact[c['exact_fp']]=rec
        structural[c['structural_fp']].append(rec)
        ratio[c['ratio_fp']].append(rec)
    def agg(d):
        out={}
        for k,rows in d.items():
            n=len(rows); hard=sum(r['hard'] for r in rows)
            panels=[r['reference_panels'] for r in rows]
            out[k]={
                'n':n,'hard_rate':hard/n,'avg_reference_panels':sum(panels)/n,
                'min_reference_panels':min(panels),'max_reference_panels':max(panels),
                'sample_case_ids':[r['case_id'] for r in rows[:5]]
            }
        return out
    return exact, agg(structural), agg(ratio)


def matrix(cases):
    X=[]; y=[]
    for c in cases:
        f=case_features(c); X.append([f[k] for k in FEATURES]); y.append(hard_label(c))
    return np.array(X,float),np.array(y,int)


def train_tree(train):
    X,y=matrix(train)
    clf=DecisionTreeClassifier(max_depth=6,min_samples_leaf=25,class_weight='balanced',random_state=42)
    clf.fit(X,y)
    return clf


def route_case(c, exact, structural, ratio, tree, hard_threshold=0.82):
    if c['exact_fp'] in exact:
        return {'route':'EXACT_CACHE','confidence':1.0,'reason':'exact fingerprint found in experience'}
    if c['ratio_fp'] in ratio:
        m=ratio[c['ratio_fp']]
        if m['n']>=2 and (m['hard_rate']>=0.80 or m['hard_rate']<=0.20):
            hard=m['hard_rate']>=0.80
            return {'route':'EARLY_RESCUE_CANDIDATE' if hard else 'FAST_BASELINE',
                    'confidence':max(m['hard_rate'],1-m['hard_rate']),
                    'reason':f"ratio memory n={m['n']} hard_rate={m['hard_rate']:.3f}"}
    if c['structural_fp'] in structural:
        m=structural[c['structural_fp']]
        if m['n']>=3 and (m['hard_rate']>=0.90 or m['hard_rate']<=0.10):
            hard=m['hard_rate']>=0.90
            return {'route':'EARLY_RESCUE_CANDIDATE' if hard else 'FAST_BASELINE',
                    'confidence':max(m['hard_rate'],1-m['hard_rate']),
                    'reason':f"structural memory n={m['n']} hard_rate={m['hard_rate']:.3f}"}
    f=case_features(c); x=np.array([[f[k] for k in FEATURES]],float)
    proba=float(tree.predict_proba(x)[0][1]) if len(tree.classes_)>1 else float(tree.classes_[0])
    if proba>=hard_threshold:
        return {'route':'EARLY_RESCUE_CANDIDATE','confidence':proba,'reason':'decision tree predicts geometric hardness'}
    return {'route':'FAST_BASELINE','confidence':1-proba,'reason':'decision tree predicts baseline-friendly'}


def calibrate_threshold(train):
    # Temporal inner split: first 80% trains, final 20% calibrates.
    cut=max(100, int(len(train)*0.8))
    fit=train[:cut]; val=train[cut:]
    clf=train_tree(fit); Xv,yv=matrix(val)
    if len(set(yv.tolist())) < 2:
        return 0.82
    probs=clf.predict_proba(Xv)[:,1]
    best=None
    for t in np.arange(0.50,0.96,0.02):
        pr=(probs>=t).astype(int)
        tp=int(((pr==1)&(yv==1)).sum()); fp=int(((pr==1)&(yv==0)).sum()); fn=int(((pr==0)&(yv==1)).sum())
        precision=tp/max(1,tp+fp); recall=tp/max(1,tp+fn)
        if precision>=0.75:
            cand=(recall,precision,-t,t)
            if best is None or cand>best: best=cand
    return float(best[3]) if best else 0.82

def evaluate(train,test,outdir):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    exact,structural,ratio=build_memories(train)
    threshold=calibrate_threshold(train)
    tree=train_tree(train)
    Xte,yte=matrix(test); pred=tree.predict(Xte)
    prob=tree.predict_proba(Xte)[:,1] if len(tree.classes_)>1 else np.zeros(len(test))
    routes=[]
    for c,yt,p in zip(test,yte,prob):
        r=route_case(c,exact,structural,ratio,tree,hard_threshold=threshold)
        r.update({'case_id':c['case_id'],'actual_hard':int(yt),'reference_panels':int(c.get('reference_panels') or 0),'lower_bound':int(case_features(c)['lower_bound']),
                  'exact_hit':c['exact_fp'] in exact,'ratio_hit':c['ratio_fp'] in ratio,'structural_hit':c['structural_fp'] in structural})
        routes.append(r)
    route_counts=Counter(r['route'] for r in routes)
    exact_hits=sum(r['exact_hit'] for r in routes); ratio_hits=sum(r['ratio_hit'] for r in routes); structural_hits=sum(r['structural_hit'] for r in routes)
    nonexact=[r for r in routes if not r['exact_hit']]
    rescue=[r for r in nonexact if r['route']=='EARLY_RESCUE_CANDIDATE']
    tp=sum(r['actual_hard']==1 for r in rescue); fp=sum(r['actual_hard']==0 for r in rescue)
    hard_total=sum(r['actual_hard']==1 for r in nonexact)
    fn=hard_total-tp
    precision=tp/max(1,tp+fp); recall=tp/max(1,hard_total)
    cm=confusion_matrix(yte,pred).tolist()
    summary={
        'train_cases':len(train),'test_cases':len(test),
        'label_definition':'hard = reference_panels > area_lower_bound (proxy; NOT equivalent to rescue-required)',
        'exact_hits':exact_hits,'exact_hit_rate':exact_hits/len(test),
        'ratio_hits':ratio_hits,'ratio_hit_rate':ratio_hits/len(test),
        'structural_hits':structural_hits,'structural_hit_rate':structural_hits/len(test),
        'route_counts':dict(route_counts),'calibrated_hard_threshold':threshold,
        'tree_accuracy':float(accuracy_score(yte,pred)),
        'tree_confusion_matrix':cm,
        'early_rescue_candidate_precision_nonexact':precision,
        'early_rescue_candidate_recall_nonexact':recall,
        'early_rescue_candidate_tp':tp,'early_rescue_candidate_fp':fp,'early_rescue_candidate_fn':fn,
        'quality_regressions':0,
        'safety':'Router is offline advisory only; it does not alter V10 or skip baseline/rescue validation.'
    }
    (outdir/'router_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    with open(outdir/'router_predictions.csv','w',encoding='utf-8',newline='') as fh:
        import csv
        w=csv.DictWriter(fh,fieldnames=list(routes[0].keys())); w.writeheader(); w.writerows(routes)
    (outdir/'decision_tree.txt').write_text(export_text(tree,feature_names=FEATURES),encoding='utf-8')
    model_json={
        'features':FEATURES,'params':tree.get_params(),
        'classes':tree.classes_.tolist(),
        'tree':{
            'children_left':tree.tree_.children_left.tolist(),'children_right':tree.tree_.children_right.tolist(),
            'feature':tree.tree_.feature.tolist(),'threshold':tree.tree_.threshold.tolist(),
            'value':tree.tree_.value.tolist()
        }
    }
    (outdir/'decision_tree_model.json').write_text(json.dumps(model_json,ensure_ascii=False),encoding='utf-8')
    # memory stats only, not huge exact plan cache
    (outdir/'ratio_memory.json').write_text(json.dumps(ratio,ensure_ascii=False),encoding='utf-8')
    structural_top={k:v for k,v in structural.items() if v['n']>=2}
    (outdir/'structural_memory.json').write_text(json.dumps(structural_top,ensure_ascii=False),encoding='utf-8')
    return summary


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--train',required=True); ap.add_argument('--test',required=True); ap.add_argument('--out',required=True)
    a=ap.parse_args(); train=json.load(open(a.train,encoding='utf-8')); test=json.load(open(a.test,encoding='utf-8'))
    print(json.dumps(evaluate(train,test,a.out),indent=2))

if __name__=='__main__': main()
