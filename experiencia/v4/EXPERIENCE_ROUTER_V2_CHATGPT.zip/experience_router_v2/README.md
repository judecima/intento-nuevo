# ExperienceRouterV2 — offline, conservador

## Objetivo
Construir una capa de experiencia sin modificar el V10. El router decide solamente entre:

- `EXACT_CACHE`: el pedido exacto ya existe en la memoria y puede recuperar un plan previamente validado.
- `FAST_BASELINE`: no existe evidencia suficiente para anticipar dificultad; ejecutar el camino rápido/baseline normal.
- `EARLY_RESCUE_CANDIDATE`: la geometría/carga parece difícil; preparar el pipeline de rescue antes, **sin elegir todavía MultiSlice/Master/Compactación**.

No cambia el motor, no elimina estrategias y no permite degradaciones de placas.

## Dataset
- Train: 5.000 casos anteriores.
- Holdout: 2.000 casos posteriores según el orden estable usado en la auditoría previa.
- No se entrena sobre los 2.000 de prueba.

## Etiqueta usada
`hard = reference_panels > area_lower_bound`.

Es un **proxy de dificultad geométrica**, no equivale a “requiere Rescue” y no debe usarse como prueba de que una estrategia concreta ganará.

## Features
- cantidad total de piezas
- cantidad de tipos
- área total / área de placa
- lower bound por área
- repetición máxima
- cantidad de anchos y altos distintos
- aspect ratio medio
- proporción de piezas finas
- proporción de piezas largas
- veta/direccionalidad
- confianza de clasificación de veta
- aspect ratio de placa

Además usa memorias `exact_fp`, `ratio_fp` y `structural_fp` ya calculadas en el dataset canónico.

## Calibración
El umbral de dificultad se elige usando solamente una partición interna temporal 80/20 de los 5.000 de entrenamiento. Se exige >=75% de precisión en esa validación interna cuando es posible y se maximiza recall dentro de esa restricción.

En esta corrida el umbral quedó en `0.82`.

## Resultado holdout 2.000
- Exact hits: 96 (4,8%).
- Ratio hits: 103 (5,15%), aunque sólo 2 tuvieron evidencia suficientemente consistente para decidir ruta directamente.
- Structural hits: 108 (5,4%), pero ninguno superó el criterio conservador actual para decidir ruta por sí solo.
- FAST_BASELINE: 1.720.
- EXACT_CACHE: 96.
- EARLY_RESCUE_CANDIDATE: 184.
- Precisión de `EARLY_RESCUE_CANDIDATE` sobre no-exactos: 71,2%.
- Recall: 40,3%.
- Accuracy del árbol como clasificador puro del proxy hard/easy: 84,1%.
- Regresiones de calidad introducidas: 0, porque el router no altera V10.

## Cómo correr

```bash
python experience_router_v2.py \
  --train train_5000.json \
  --test test_2000.json \
  --out results
```

## Qué NO hace todavía
No decide `MultiSlice`, `Pattern Master`, `Compactación` o `OneBoard` porque no existe aún una etiqueta suficientemente amplia y limpia de ganador por estrategia para los miles de casos.

La próxima etapa correcta es ejecutar un benchmark estratificado de estrategias en casos seleccionados (especialmente `EARLY_RESCUE_CANDIDATE`) y construir `StrategyOutcomeMemory`, sin modificar el baseline.
