import json, sys
sys.path.insert(0,'.')
import experience_router_v2 as er

def main():
    train=json.load(open('/mnt/data/xml_experience/analysis/holdout_5k_2k/train_5000.json',encoding='utf-8'))
    test=json.load(open('/mnt/data/xml_experience/analysis/holdout_5k_2k/test_2000.json',encoding='utf-8'))
    a=er.case_features(train[0]); b=er.case_features(train[0])
    assert a==b, 'features must be deterministic'
    assert a['piece_count']==train[0]['piece_count']
    exact,structural,ratio=er.build_memories(train)
    tree=er.train_tree(train)
    # Known train case must be exact cache.
    r=er.route_case(train[0],exact,structural,ratio,tree)
    assert r['route']=='EXACT_CACHE'
    # Holdout exact hits must be cacheable by exact fingerprint only.
    hits=[c for c in test if c['exact_fp'] in exact]
    assert len(hits)==96, len(hits)
    # Router must never claim a concrete rescue strategy: this V2 is advisory.
    allowed={'EXACT_CACHE','FAST_BASELINE','EARLY_RESCUE_CANDIDATE'}
    for c in test[:300]:
        assert er.route_case(c,exact,structural,ratio,tree)['route'] in allowed
    print('OK: deterministic features, exact memory, 96 holdout hits, conservative routes')

if __name__=='__main__': main()
