# Benchmark — ExperienceRouterV2

## Resultado

| Métrica | Valor |
|---|---:|
| Train | 5000 |
| Holdout | 2000 |
| Exact hits | 96 (4.80%) |
| Ratio hits | 103 (5.15%) |
| Structural hits | 108 (5.40%) |
| FAST_BASELINE | 1720 |
| EXACT_CACHE | 96 |
| EARLY_RESCUE_CANDIDATE | 184 |
| Threshold | 0.82 |
| Tree accuracy | 84.10% |
| Rescue-candidate precision | 71.20% |
| Rescue-candidate recall | 40.31% |
| Regresiones introducidas | 0 |

## Importante
La etiqueta `hard` es `reference_panels > lowerBoundArea`. Sirve para priorización y benchmarking, no demuestra que un Rescue concreto sea necesario o ganador.
