# EXPERIENCE OPTIMIZER — SOURCE OF TRUTH — ROUTER V2

## ESTADO ACTUAL
Etapa: ExperienceRouterV2 offline
Estado: COMPLETADA / NO INTEGRADA A V10
Dataset: 5.000 train + 2.000 holdout
Motor productivo modificado: NO

## OBJETIVO
Usar experiencia histórica para evitar recomputaciones exactas y anticipar pedidos geométricamente difíciles, sin imponer rescates no validados.

## CAMBIOS
- Implementado extractor de features offline.
- Implementadas memorias exact/ratio/structural sobre fingerprints existentes.
- Implementado árbol de decisión interpretable (profundidad máxima 6).
- Implementada calibración temporal interna del threshold.
- Implementado router conservador de 3 salidas.
- No se tocó V10.

## REGLAS INVIOLABLES
- `EXACT_CACHE` requiere plan previamente validado y debe revalidarse al recuperar.
- `structuralFingerprint` no autoriza reutilizar directamente un plan.
- `EARLY_RESCUE_CANDIDATE` NO significa ejecutar una estrategia concreta.
- V10 sigue siendo fallback/autoridad.
- Cero regresiones es requisito para integración.

## PRUEBAS
`python test_router_v2.py`

Resultado:
`OK: deterministic features, exact memory, 96 holdout hits, conservative routes`

## BENCHMARK HOLDOUT
Train: 5.000
Test: 2.000

- exact hits: 96 / 4,8%
- ratio hits: 103 / 5,15%
- structural hits: 108 / 5,4%
- FAST_BASELINE: 1.720
- EXACT_CACHE: 96
- EARLY_RESCUE_CANDIDATE: 184
- threshold calibrado: 0,82
- tree accuracy (proxy hard/easy): 84,1%
- early rescue precision: 71,20%
- early rescue recall: 40,31%
- regresiones: 0 (offline/advisory)

## INTERPRETACIÓN
El router ya sirve para:
1. evitar al menos 96 recomputaciones exactas en el holdout;
2. reducir el universo de casos en los que vale la pena invertir benchmark/rescue: 184 de 2.000;
3. mantener 1.720 pedidos en FAST_BASELINE sin agregar rescates preventivos.

No está validado todavía para elegir qué Rescue gana.

## HALLAZGOS
- Exact Memory es la señal de mayor confianza.
- Ratio Memory aporta algunos casos con evidencia fuerte pero aún poca cobertura.
- Structural Memory sola sigue siendo demasiado gruesa; cantidades/carga importan.
- El árbol mejora cobertura sobre los misses pero requiere un threshold conservador para no gastar CPU de más.

## REGRESIONES
0 introducidas por esta etapa porque no modifica decisiones finales del optimizador.

## PROPUESTAS NO IMPLEMENTADAS
### StrategyOutcomeMemory
Ejecutar, sobre un conjunto estratificado y con timeout aislado:
- baseline
- OneBoard cuando LB=1
- Compactación
- MultiSlice
- Pattern Master

Guardar ganador por `ratioFingerprint + features de carga`, incluyendo tiempo y placas.

No implementado todavía porque requiere benchmark costoso y no debe inferirse sin datos.

## SIGUIENTE PASO
Construir `StrategyOutcomeMemory` offline sobre los 184 `EARLY_RESCUE_CANDIDATE` + controles fáciles, y validar en un segundo holdout antes de permitir que el router ordene rescates.
