import { createRequire } from "node:module";

import { describe, expect, it } from "vitest";

import {
  computeLowerBound,
  computeLowerBoundCascade,
  strongLowerBound,
  type LowerBoundLine,
  type LowerBoundOptions
} from "@/lib/optimizer/bounds/lower-bounds";

const require = createRequire(import.meta.url);

const legacyMotor = require("../../src/lib/optimizer/legacy/motor.cjs") as {
  optimizar(
    lineas: Array<Record<string, unknown>>,
    config: Record<string, unknown>
  ): { resumen: { placas: number } };
};

const baseOptions: LowerBoundOptions = {
  placaBase: 2750,
  placaAltura: 1830,
  refiladoX: 10,
  refiladoY: 10,
  sierra: 4.5,
  materialConVeta: false,
  descontarCanto: false,
  cantoEspesor: 0
};

function line(base: number, altura: number, cant: number, veta = false): LowerBoundLine {
  return { base, altura, cant, veta };
}

/* La cota vigente hoy en legacy-engine.ts / v10.cjs, para comparar. */
function cotaAreaActual(lineas: LowerBoundLine[], opts: LowerBoundOptions): number {
  const areaTotal = lineas.reduce((sum, l) => sum + l.cant * l.base * l.altura, 0);
  const areaPlaca = (opts.placaBase - (opts.refiladoX ?? 0)) * (opts.placaAltura - (opts.refiladoY ?? 0));
  return Math.ceil(areaTotal / areaPlaca - 1e-9);
}

describe("computeLowerBound", () => {
  it("nunca queda por debajo de la cota de area vigente", () => {
    const casos: LowerBoundLine[][] = [
      [line(600, 400, 12)],
      [line(2000, 900, 3), line(700, 300, 20)],
      [line(1200, 600, 8), line(400, 400, 15), line(250, 180, 40)],
      [line(2730, 1810, 1)],
      [line(900, 900, 7)]
    ];

    for (const lineas of casos) {
      const res = computeLowerBound(lineas, baseOptions);
      expect(res.best).toBeGreaterThanOrEqual(cotaAreaActual(lineas, baseOptions));
      expect(res.best).toBeGreaterThanOrEqual(res.area);
    }
  });

  it("con todas las cotas apagadas reproduce exactamente la cota de area", () => {
    const lineas = [line(1200, 600, 9), line(430, 380, 22)];
    const res = computeLowerBound(lineas, baseOptions, {
      usarKerf: false,
      usarDff: false,
      usarRaster: false
    });
    expect(res.best).toBe(cotaAreaActual(lineas, baseOptions));
    expect(res.binding).toBe("area");
  });

  it("cuenta una placa por pieza cuando cada pieza supera la mitad en ambos ejes", () => {
    // 5 piezas de 1500x1000 CON VETA en una placa util de 2740x1820. Sin
    // rotacion, cada una supera W/2 y H/2, asi que dos no pueden compartir
    // placa. La cota de area dice 2; la DFF con epsilon = delta = 1/2 dice 5.
    const opts: LowerBoundOptions = { ...baseOptions, materialConVeta: true };
    const lineas = [line(1500, 1000, 5, true)];
    const res = computeLowerBound(lineas, opts);
    expect(cotaAreaActual(lineas, opts)).toBeLessThan(5);
    expect(res.best).toBe(5);
    expect(res.dff).toBe(5);
  });

  it("no infla la cota cuando la rotacion permite compartir placa", () => {
    // Las mismas 5 piezas sin veta: una acostada y una parada entran juntas
    // (1500 + 4.5 + 1000 <= 2740), asi que 5 seria una cota invalida.
    const res = computeLowerBound([line(1500, 1000, 5)], baseOptions);
    expect(res.best).toBeLessThanOrEqual(3);
  });

  it("el inflado por kerf detecta el caso que el area declara justo", () => {
    // Placa util 1000x1000 sin refilado, cuatro piezas de 500x500.
    // Por area entran exactas en 1 placa; con sierra 5 es imposible.
    const opts: LowerBoundOptions = {
      placaBase: 1000,
      placaAltura: 1000,
      refiladoX: 0,
      refiladoY: 0,
      sierra: 5,
      materialConVeta: false
    };
    const lineas = [line(500, 500, 4)];
    expect(cotaAreaActual(lineas, opts)).toBe(1);
    expect(computeLowerBound(lineas, opts).best).toBeGreaterThanOrEqual(2);
  });

  it("la criba reduce la placa efectiva cuando las medidas no la cubren", () => {
    // Piezas de 400 mm con sierra 0 sobre una placa de 1000: como maximo se
    // consumen 800 mm sobre cada eje, no 1000.
    const opts: LowerBoundOptions = {
      placaBase: 1000,
      placaAltura: 1000,
      refiladoX: 0,
      refiladoY: 0,
      sierra: 0,
      materialConVeta: false
    };
    const res = computeLowerBound([line(400, 400, 10)], opts);
    expect(res.rasterAplicado).toBe(true);
    expect(res.anchoEfectivo).toBeCloseTo(800, 6);
    expect(res.altoEfectivo).toBeCloseTo(800, 6);
    // 10 piezas de 160000 mm2 sobre 640000 utiles por placa => 3 placas.
    expect(res.best).toBeGreaterThanOrEqual(3);
    expect(cotaAreaActual([line(400, 400, 10)], opts)).toBe(2);
  });


  it("la proyeccion ve lo que el area no ve", () => {
    // Placa 1000x1000 sin kerf. Piezas de 300x600: toda orientacion admisible
    // deja 600 > 500 sobre algun eje... no: 300x600 rotada es 600x300, que si
    // baja de la mitad. Usamos 300x600 CON VETA para fijar la orientacion.
    const opts: LowerBoundOptions = {
      placaBase: 1000,
      placaAltura: 1000,
      refiladoX: 0,
      refiladoY: 0,
      sierra: 0,
      materialConVeta: true
    };
    // 4 piezas de 300 de ancho por 600 de alto: cada una cruza y = 500, asi
    // que van todas de canto sobre X y solo entran 3 por placa.
    const lineas = [line(300, 600, 4, true)];
    const res = computeLowerBound(lineas, opts);
    expect(cotaAreaActual(lineas, opts)).toBe(1);
    expect(res.proyeccion).toBe(2);
    expect(res.best).toBeGreaterThanOrEqual(2);
  });

  it("la clique cuenta piezas que no pueden compartir placa", () => {
    // 3 piezas de 1500x1000 con veta en 2740x1820: incompatibles entre si y
    // consigo mismas, asi que la clique vale 3.
    const opts: LowerBoundOptions = { ...baseOptions, materialConVeta: true };
    const res = computeLowerBound([line(1500, 1000, 3, true)], opts);
    expect(res.clique).toBe(3);
  });

  it("la clique no inventa conflictos cuando las piezas si conviven", () => {
    // 400x400 en 2740x1820: entran muchisimas juntas, la clique vale 1.
    const res = computeLowerBound([line(400, 400, 20)], baseOptions);
    expect(res.clique).toBe(1);
  });

  it("cada cota se puede apagar por separado", () => {
    const lineas = [line(1500, 1000, 5, true)];
    const opts: LowerBoundOptions = { ...baseOptions, materialConVeta: true };
    const sinClique = computeLowerBound(lineas, opts, { usarClique: false });
    expect(sinClique.clique).toBe(0);
    const sinProy = computeLowerBound(lineas, opts, { usarProyeccion: false });
    expect(sinProy.proyeccion).toBe(0);
  });

  it("la cascada saltea la criba cuando la etapa barata ya certifica", () => {
    // 5 piezas de 1500x1000 con veta: la clique certifica 5 sin tocar la criba.
    const opts: LowerBoundOptions = { ...baseOptions, materialConVeta: true };
    const res = computeLowerBoundCascade([line(1500, 1000, 5, true)], opts, 5);
    expect(res.etapa).toBe("barata");
    expect(res.rasterCorrio).toBe(false);
    expect(res.best).toBeGreaterThanOrEqual(5);
  });

  it("la cascada corre la criba cuando la etapa barata no alcanza", () => {
    const opts: LowerBoundOptions = {
      placaBase: 1000,
      placaAltura: 1000,
      refiladoX: 0,
      refiladoY: 0,
      sierra: 0,
      materialConVeta: false
    };
    const res = computeLowerBoundCascade([line(400, 400, 10)], opts, 99);
    expect(res.etapa).toBe("completa");
    expect(res.rasterCorrio).toBe(true);
    expect(res.best).toBeGreaterThanOrEqual(res.bestBarata);
  });

  it("la cascada sin incumbente nunca queda por debajo de la cota completa", () => {
    const casos: LowerBoundLine[][] = [
      [line(400, 400, 10)],
      [line(1200, 600, 8), line(430, 380, 22)],
      [line(2100, 600, 3), line(580, 350, 17), line(720, 450, 9)]
    ];
    for (const lineas of casos) {
      const cascada = computeLowerBoundCascade(lineas, baseOptions);
      const completa = computeLowerBound(lineas, baseOptions);
      expect(cascada.best).toBe(completa.best);
    }
  });

  it("respeta la veta: sin rotacion la cota puede subir", () => {
    const opts: LowerBoundOptions = { ...baseOptions, materialConVeta: true };
    const conVeta = computeLowerBound([line(1700, 500, 6, true)], opts);
    const sinVeta = computeLowerBound([line(1700, 500, 6, false)], opts);
    expect(conVeta.best).toBeGreaterThanOrEqual(sinVeta.best);
  });

  it("es determinista", () => {
    const lineas = [line(812, 517, 13), line(433, 296, 27), line(1204, 604, 5)];
    const a = computeLowerBound(lineas, baseOptions);
    const b = computeLowerBound(lineas, baseOptions);
    expect(a).toEqual(b);
  });

  it("marca infactible la pieza que no entra en la placa", () => {
    const res = computeLowerBound([line(3000, 500, 1)], baseOptions);
    expect(res.factible).toBe(false);
  });

  it("devuelve 0 sin lineas", () => {
    expect(strongLowerBound([], baseOptions)).toBe(0);
  });

  it("descuenta el canto igual que medidaCorte", () => {
    const opts: LowerBoundOptions = { ...baseOptions, descontarCanto: true, cantoEspesor: 2 };
    const conCanto: LowerBoundLine = {
      base: 600,
      altura: 400,
      cant: 30,
      cantos: { izq: true, der: true, arr: true, aba: true }
    };
    const res = computeLowerBound([conCanto], opts);
    const sin = computeLowerBound([line(600, 400, 30)], opts);
    // 596x396 nunca puede necesitar mas placas que 600x400.
    expect(res.best).toBeLessThanOrEqual(sin.best);
  });
});

/* ==========================================================================
   REGRESION CONTRA EL MOTOR REAL

   Test de regresion, no de validez. Contrastar contra un plan FACTIBLE solo
   detecta una cota que supera un valor ALCANZABLE. El modo de falla que
   importa es el otro: la cota iguala las placas del plan pero el optimo
   verdadero es menor, y ahi el motor tampoco encuentra nada mejor, asi que
   este test calla.

   La prueba de validez esta mas abajo, contra un oracle exacto.

   Sirve igual: cubre instancias mucho mas grandes que las que el oracle puede
   resolver, y detecta cualquier cota groseramente rota.
   ========================================================================== */
function rng(semilla: number) {
  let s = semilla >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

describe("computeLowerBound nunca supera un plan factible", () => {
  it("sobre 60 instancias aleatorias deterministas", () => {
    const random = rng(20260904);
    const opts: LowerBoundOptions = {
      placaBase: 1200,
      placaAltura: 800,
      refiladoX: 0,
      refiladoY: 0,
      sierra: 4.5,
      materialConVeta: false,
      descontarCanto: false,
      cantoEspesor: 0
    };

    for (let caso = 0; caso < 60; caso++) {
      const tipos = 1 + Math.floor(random() * 5);
      const lineas: LowerBoundLine[] = [];
      for (let t = 0; t < tipos; t++) {
        // Medidas en decimas redondas para que la criba pueda aplicar.
        const base = 100 + Math.round(random() * 90) * 10;
        const altura = 100 + Math.round(random() * 60) * 10;
        const cant = 1 + Math.floor(random() * 6);
        lineas.push(line(base, altura, cant));
      }

      const plan = legacyMotor.optimizar(
        lineas.map((l) => ({ base: l.base, altura: l.altura, cant: l.cant, detalle: "", veta: false })),
        { ...opts, etapas: 4, pases: 1, restartsPorPlaca: 2, usarRescue: false, multiVariantes: false }
      );

      const cota = computeLowerBound(lineas, opts);
      expect(cota.factible).toBe(true);
      expect(
        cota.best,
        `caso ${caso}: cota ${cota.best} (${cota.binding}) supera plan de ${plan.resumen.placas} placas; lineas=${JSON.stringify(lineas)}`
      ).toBeLessThanOrEqual(plan.resumen.placas);
    }
  });

  it("sobre instancias con veta y rotacion restringida", () => {
    const random = rng(778899);
    const opts: LowerBoundOptions = {
      placaBase: 1500,
      placaAltura: 900,
      refiladoX: 5,
      refiladoY: 5,
      sierra: 4.5,
      materialConVeta: true,
      descontarCanto: false,
      cantoEspesor: 0
    };

    for (let caso = 0; caso < 30; caso++) {
      const tipos = 1 + Math.floor(random() * 4);
      const lineas: LowerBoundLine[] = [];
      for (let t = 0; t < tipos; t++) {
        const base = 100 + Math.round(random() * 100) * 10;
        const altura = 100 + Math.round(random() * 70) * 10;
        lineas.push(line(base, altura, 1 + Math.floor(random() * 5), random() < 0.5));
      }

      const plan = legacyMotor.optimizar(
        lineas.map((l) => ({ base: l.base, altura: l.altura, cant: l.cant, detalle: "", veta: l.veta })),
        { ...opts, etapas: 4, pases: 1, restartsPorPlaca: 2, usarRescue: false, multiVariantes: false }
      );

      const cota = computeLowerBound(lineas, opts);
      expect(
        cota.best,
        `caso ${caso}: cota ${cota.best} (${cota.binding}) supera plan de ${plan.resumen.placas} placas; lineas=${JSON.stringify(lineas)}`
      ).toBeLessThanOrEqual(plan.resumen.placas);
    }
  });
});

/* ==========================================================================
   VALIDEZ CONTRA UN ORACLE EXACTO

   Esta es la prueba de validez. Resuelve el optimo guillotina EXACTO por
   enumeracion y verifica que ninguna cota lo supere. A diferencia del test de
   regresion de arriba, detecta el falso certificado: la cota que iguala las
   placas de un plan subóptimo.

   El oracle vive en el repo a proposito. Un oracle externo prueba la version
   auditada; este prueba la version que este commit tiene en disco, y corre en
   CI cada vez que alguien toca lower-bounds.ts.

   Metodo: para cada subconjunto se calcula el conjunto Pareto-minimal de
   bounding boxes alcanzables por un arbol guillotina, combinando subconjuntos
   de a pares (lado a lado sumando kerf, o apilados sumando kerf). Un
   subconjunto entra en una placa si alguna de sus cajas cabe. Despues, DP
   sobre subconjuntos para la particion minima en placas.

   Exponencial: se limita a 6 piezas por instancia.
   ========================================================================== */
type Caja = [number, number];

function paretoMinimal(cajas: Caja[]): Caja[] {
  const orden = [...cajas].sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const out: Caja[] = [];
  for (const c of orden) {
    if (!out.some((o) => o[0] <= c[0] + 1e-9 && o[1] <= c[1] + 1e-9)) out.push(c);
  }
  return out;
}

/** Optimo guillotina exacto en placas. Devuelve Infinity si algo no entra. */
function optimoExacto(
  piezas: Array<{ w: number; h: number; rota: boolean }>,
  W: number,
  H: number,
  s: number
): number {
  const n = piezas.length;
  const total = 1 << n;

  // cajas[mask] = bounding boxes Pareto-minimales alcanzables con ese subconjunto
  const cajas: Caja[][] = new Array(total);
  cajas[0] = [];
  for (let i = 0; i < n; i++) {
    const p = piezas[i];
    const ors: Caja[] = [[p.w, p.h]];
    if (p.rota && Math.abs(p.w - p.h) > 1e-9) ors.push([p.h, p.w]);
    cajas[1 << i] = paretoMinimal(ors);
  }

  for (let mask = 1; mask < total; mask++) {
    if (cajas[mask]) continue;
    const bajo = mask & -mask; // fijar el elemento mas bajo en A evita duplicar splits
    const acc: Caja[] = [];
    for (let a = (mask - 1) & mask; a > 0; a = (a - 1) & mask) {
      if (!(a & bajo)) continue;
      const b = mask ^ a;
      if (!b) continue;
      for (const [wa, ha] of cajas[a]) {
        for (const [wb, hb] of cajas[b]) {
          acc.push([wa + s + wb, Math.max(ha, hb)]);
          acc.push([Math.max(wa, wb), ha + s + hb]);
        }
      }
    }
    cajas[mask] = paretoMinimal(acc);
  }

  const entra = new Array<boolean>(total).fill(false);
  for (let mask = 1; mask < total; mask++) {
    entra[mask] = cajas[mask].some(([w, h]) => w <= W + 1e-9 && h <= H + 1e-9);
  }

  const dp = new Array<number>(total).fill(Infinity);
  dp[0] = 0;
  for (let mask = 1; mask < total; mask++) {
    const bajo = mask & -mask;
    for (let sub = mask; sub > 0; sub = (sub - 1) & mask) {
      if (!(sub & bajo) || !entra[sub]) continue;
      const resto = dp[mask ^ sub];
      if (resto + 1 < dp[mask]) dp[mask] = resto + 1;
    }
  }
  return dp[total - 1];
}

describe("computeLowerBound nunca supera el optimo guillotina exacto", () => {
  function correrOracle(semilla: number, casos: number, fraccionario: boolean) {
    const random = rng(semilla);
    let corridos = 0;
    let eleva = 0;

    for (let caso = 0; caso < casos; caso++) {
      const W = 400 + Math.floor(random() * 500);
      const H = 300 + Math.floor(random() * 400);
      const s = fraccionario ? [0, 2.5, 4.5][Math.floor(random() * 3)] : [0, 3, 5][Math.floor(random() * 3)];
      const conVeta = random() < 0.4;
      const n = 2 + Math.floor(random() * 5); // 2..6 piezas

      const piezas: Array<{ w: number; h: number; rota: boolean }> = [];
      const lineas: LowerBoundLine[] = [];
      let ok = true;
      for (let i = 0; i < n; i++) {
        const paso = fraccionario ? 0.5 : 1;
        const w = Math.round((60 + random() * (W - 70)) / paso) * paso;
        const h = Math.round((60 + random() * (H - 70)) / paso) * paso;
        const veta = conVeta && random() < 0.5;
        const rota = !veta;
        const cabe = (w <= W && h <= H) || (rota && h <= W && w <= H);
        if (!cabe) {
          ok = false;
          break;
        }
        piezas.push({ w, h, rota });
        lineas.push({ base: w, altura: h, cant: 1, veta });
      }
      if (!ok) continue;

      const opts: LowerBoundOptions = {
        placaBase: W,
        placaAltura: H,
        refiladoX: 0,
        refiladoY: 0,
        sierra: s,
        materialConVeta: conVeta
      };

      const optimo = optimoExacto(piezas, W, H, s);
      if (!Number.isFinite(optimo)) continue;

      const cota = computeLowerBound(lineas, opts);
      const cascada = computeLowerBoundCascade(lineas, opts);
      corridos++;
      if (cota.best > cota.area) eleva++;

      const detalle =
        `W=${W} H=${H} s=${s} veta=${conVeta} piezas=${JSON.stringify(piezas)} ` +
        `cotas=${JSON.stringify({
          area: cota.area,
          kerf: cota.kerf,
          raster: cota.raster,
          dff: cota.dff,
          proyeccion: cota.proyeccion,
          clique: cota.clique
        })}`;

      expect(cota.best, `optimo=${optimo} best=${cota.best} (${cota.binding}) ${detalle}`).toBeLessThanOrEqual(optimo);
      expect(cascada.best, `cascada supera el optimo: ${detalle}`).toBeLessThanOrEqual(optimo);
    }

    return { corridos, eleva };
  }

  it("sobre instancias con medidas enteras", () => {
    const { corridos, eleva } = correrOracle(112233, 700, false);
    expect(corridos).toBeGreaterThan(300);
    expect(eleva).toBeGreaterThan(0);
  }, 120_000);

  it("sobre instancias con medidas y kerf fraccionarios", () => {
    const { corridos, eleva } = correrOracle(445566, 700, true);
    expect(corridos).toBeGreaterThan(300);
    expect(eleva).toBeGreaterThan(0);
  }, 120_000);
});
