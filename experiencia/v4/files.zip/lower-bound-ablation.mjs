#!/usr/bin/env node
/**
 * Medicion offline de la COTA INFERIOR FUERTE.
 *
 * No forma parte del flujo de la aplicacion. No modifica el motor, sus heuristicas, sus
 * limites ni ningun default. Solo calcula un numero adicional por caso y lo compara con
 * la cota de area vigente y con las placas que efectivamente produce el motor.
 *
 * Responde dos preguntas separadas:
 *
 *   1) VALIDEZ. Existe algun caso del corpus donde la cota fuerte supere las placas del
 *      plan factible que produce el motor? Si existe uno solo, la cota es invalida y no
 *      se puede usar como compuerta. Este chequeo es el gate, y corre en modo `verify`.
 *
 *   2) VALOR. En cuantos casos que HOY quedan fuera de la cota de area, la cota fuerte
 *      demuestra que el plan ya es optimo? Esos son exactamente los casos donde la
 *      cadena de rescates (MultiSlice, OneBoard, Pattern Master) es trabajo demostrable-
 *      mente inutil. En el diagnostico del 2026-09-04, 320 casos del holdout quedaban
 *      fuera de cota y consumian el 87.6% del tiempo.
 *
 * Modos:
 *
 *   node scripts/lower-bound-ablation.mjs bounds  --train 5000 --holdout 2000
 *       Solo cotas, sin correr el motor. Barato: milisegundos por caso. Da la
 *       distribucion de cuanto levanta la cota y cual de las cuatro queda activa.
 *
 *   node scripts/lower-bound-ablation.mjs verify  --train 5000 --holdout 2000
 *       Corre el motor y contrasta cota <= placas caso por caso. Es el gate de validez.
 *       Caro: usa la misma estrategia/perfil que el benchmark de referencia.
 *
 *   node scripts/lower-bound-ablation.mjs report  --train 5000 --holdout 2000
 *       Resume los .jsonl ya escritos.
 *
 * Opciones: --corpus <dir> --strategy baseline|v10 --out <dir> --limit N --maxNew N
 *           --files <lista.txt> --orders <lista|archivo> --label <id> --set train|holdout --rebuild
 *
 * --orders acepta numeros de pedido separados por coma, o la ruta a un .txt con uno por
 * linea, o a un .json que contenga un array de numeros o un objeto con `orders` o con
 * `rows[].order`. Sirve para apuntar el modulo a una tanda concreta, por ejemplo los 50
 * casos del gate staged V14:
 *
 *     node scripts/lower-bound-ablation.mjs bounds --orders experiencia/v14_staged_historical_50.json
 *
 * El match se hace con la misma funcion orderNumber() que usa el split, asi que no hace
 * falta conocer el nombre completo del XML.
 *
 * El split del corpus es el mismo que usa scripts/experience-benchmark.mjs (orden por
 * numero de pedido embebido en el nombre, split sobre casos canonicos) para que los
 * resultados sean comparables con los benchmarks ya registrados.
 */
import { build } from "esbuild";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const REPO = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const DEFAULT_CORPUS = "D:/proyectos asistidos/lepton/data/lepton-xml";

const args = parseArgs(process.argv.slice(2));
const mode = args._[0];
if (!["bounds", "verify", "report"].includes(mode)) {
  console.error("modo requerido: bounds | verify | report");
  process.exit(1);
}

const corpus = args.corpus ?? DEFAULT_CORPUS;
const trainSize = Number(args.train ?? 5000);
const holdoutSize = Number(args.holdout ?? 2000);
const strategy = args.strategy ?? "v10";
const set = args.set ?? "holdout";
const outDir = args.out ?? join(REPO, "experiencia", "bounds");
const label = args.label ?? null;
const limit = args.limit === undefined ? null : Number(args.limit);
const maxNew = args.maxNew === undefined ? null : Number(args.maxNew);
const tag = `${strategy}-${set}-${trainSize}-${holdoutSize}`;
const fileFilter = args.files ? new Set(readFileSync(args.files, "utf8").split(/\r?\n/).filter(Boolean)) : null;
const orderFilter = args.orders ? parseOrders(args.orders) : null;

function parseOrders(spec) {
  let raw = spec;
  if (existsSync(spec)) {
    const text = readFileSync(spec, "utf8");
    if (spec.toLowerCase().endsWith(".json")) {
      const parsed = JSON.parse(text);
      const list = Array.isArray(parsed)
        ? parsed
        : Array.isArray(parsed.orders)
          ? parsed.orders
          : Array.isArray(parsed.rows)
            ? parsed.rows.map((row) => row.order)
            : [];
      return new Set(list.map(Number).filter((value) => Number.isFinite(value)));
    }
    raw = text;
  }
  return new Set(
    String(raw)
      .split(/[\s,]+/)
      .map(Number)
      .filter((value) => Number.isFinite(value))
  );
}

mkdirSync(outDir, { recursive: true });

const optimizer = await loadOptimizer(Boolean(args.rebuild));

if (mode === "report") report();
else await run();

// ---------------------------------------------------------------- carga del bundle

async function loadOptimizer(rebuild) {
  const bundlePath = join(REPO, "node_modules", ".cache", "lower-bound-ablation", "optimizer.mjs");
  const anchor = pathToFileURL(join(REPO, "src", "lib", "optimizer", "experience", "revalidate.ts")).href;

  if (rebuild || !existsSync(bundlePath)) {
    mkdirSync(dirname(bundlePath), { recursive: true });
    await build({
      entryPoints: [join(REPO, "src", "lib", "optimizer", "index.ts")],
      bundle: true,
      platform: "node",
      format: "esm",
      target: "node22",
      outfile: bundlePath,
      define: { "import.meta.url": JSON.stringify(anchor) },
      logLevel: "warning"
    });
  }

  return import(pathToFileURL(bundlePath).href);
}

// ---------------------------------------------------------------- dataset y split

function orderNumber(fileName) {
  const runs = fileName.replace(/\.xml$/i, "").match(/\d+/g);
  if (!runs) return Number.POSITIVE_INFINITY;
  const last = runs[runs.length - 1];
  return Number(last.length > 7 ? last.slice(-7) : last);
}

function corpusFiles() {
  return readdirSync(corpus)
    .filter((name) => name.toLowerCase().endsWith(".xml"))
    .map((name) => ({ name, order: orderNumber(name) }))
    .sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    .map((entry) => entry.name);
}

function buildSplit() {
  const files = corpusFiles();
  const train = [];
  const holdout = [];
  const skipped = { parseError: 0, excluded: 0, adapterError: 0 };

  for (const name of files) {
    if (holdout.length >= holdoutSize) break;
    const parsed = parseFile(name);
    if (!parsed.ok) {
      skipped[parsed.kind] = (skipped[parsed.kind] ?? 0) + 1;
      continue;
    }
    (train.length < trainSize ? train : holdout).push(parsed);
  }

  return { train, holdout, skipped, files: files.length };
}

function parseFile(name) {
  let xml;
  try {
    xml = readFileSync(join(corpus, name), "utf8");
  } catch {
    return { ok: false, kind: "parseError", name };
  }

  let canonical;
  try {
    canonical = optimizer.parseCanonicalXml(xml, { fileName: name });
  } catch (error) {
    return { ok: false, kind: error?.code === "mixed-board-formats" ? "excluded" : "parseError", name };
  }
  if (!canonical?.case) return { ok: false, kind: "excluded", name };

  let input;
  try {
    input = optimizer.benchmarkInputFromCanonicalCase(canonical.case, { strategy });
  } catch {
    return { ok: false, kind: "adapterError", name };
  }

  return { ok: true, name, input };
}

// ---------------------------------------------------------------- corrida

async function run() {
  const split = buildSplit();
  const cases = set === "train" ? split.train : split.holdout;
  const filtered = cases.filter(
    (item) =>
      (fileFilter === null || fileFilter.has(item.name)) &&
      (orderFilter === null || orderFilter.has(orderNumber(item.name)))
  );
  const selected = limit === null ? filtered : filtered.slice(0, limit);

  const outPath = join(outDir, `${mode}-${tag}${label === null ? "" : "-" + label}.jsonl`);
  const done = new Set(readJsonl(outPath).map((record) => record.file));
  const remaining = selected.filter((item) => !done.has(item.name));
  const pending = maxNew === null ? remaining : remaining.slice(0, maxNew);

  console.log(
    `corpus=${split.files} set=${set} casos=${selected.length} ya_resueltos=${done.size} ` +
      `pendientes=${pending.length} skipped=${JSON.stringify(split.skipped)}`
  );

  let i = 0;
  for (const item of pending) {
    i++;
    const record = { file: item.name, mode, strategy };

    try {
      const bound = optimizer.lowerBoundForInput(item.input);
      record.area = bound.area;
      record.kerf = bound.kerf;
      record.raster = bound.raster;
      record.dff = bound.dff;
      record.best = bound.best;
      record.binding = bound.binding;
      record.rasterAplicado = bound.rasterAplicado;
      record.factible = bound.factible;
      record.piezas = item.input.pieces.reduce((total, piece) => total + piece.quantity, 0);
      record.tipos = item.input.pieces.length;

      if (mode === "verify") {
        const t0 = Date.now();
        const result = optimizer.optimizeProject(item.input);
        record.ms = Date.now() - t0;
        record.placas = result.boards.length;
        record.valida = bound.best <= result.boards.length;
        if (!record.valida) {
          console.error(
            `VIOLACION ${item.name}: cota=${bound.best} (${bound.binding}) placas=${record.placas}`
          );
        }
      }
    } catch (error) {
      record.error = String(error?.message ?? error);
    }

    appendFileSync(outPath, JSON.stringify(record) + "\n");
    if (i % 100 === 0) console.log(`  ${i}/${pending.length}`);
  }

  report();
}

// ---------------------------------------------------------------- reporte

function report() {
  const boundsPath = join(outDir, `bounds-${tag}${label === null ? "" : "-" + label}.jsonl`);
  const verifyPath = join(outDir, `verify-${tag}${label === null ? "" : "-" + label}.jsonl`);
  const records = [...readJsonl(boundsPath), ...readJsonl(verifyPath)].filter((r) => !r.error && r.factible);
  if (!records.length) {
    console.log("sin registros");
    return;
  }

  // Un caso puede estar en los dos archivos; gana el que tiene placas medidas.
  const porCaso = new Map();
  for (const record of records) {
    const previo = porCaso.get(record.file);
    if (!previo || (record.placas !== undefined && previo.placas === undefined)) {
      porCaso.set(record.file, record);
    }
  }
  const casos = [...porCaso.values()];

  const binding = { area: 0, kerf: 0, raster: 0, dff: 0 };
  let levanta = 0;
  let placasExtra = 0;
  for (const caso of casos) {
    binding[caso.binding] = (binding[caso.binding] ?? 0) + 1;
    if (caso.best > caso.area) {
      levanta++;
      placasExtra += caso.best - caso.area;
    }
  }

  console.log("");
  console.log(`## COTA INFERIOR FUERTE - ${tag}`);
  console.log(`casos: ${casos.length}`);
  console.log(
    `cota mas alta que la de area: ${levanta} (${pct(levanta, casos.length)}), ` +
      `+${placasExtra} placas de cota en total`
  );
  console.log(`cota activa: ${JSON.stringify(binding)}`);

  const conPlan = casos.filter((caso) => caso.placas !== undefined);
  if (!conPlan.length) {
    console.log("sin corrida `verify`: no hay chequeo de validez ni medicion de cierre de gap");
    return;
  }

  const violaciones = conPlan.filter((caso) => caso.valida === false);
  console.log("");
  console.log(`VALIDEZ  casos con plan: ${conPlan.length}  violaciones: ${violaciones.length}`);
  if (violaciones.length) {
    console.log("LA COTA ES INVALIDA. No usar como compuerta. Primeras 10:");
    for (const caso of violaciones.slice(0, 10)) {
      console.log(`  ${caso.file}: cota=${caso.best} (${caso.binding}) placas=${caso.placas}`);
    }
    return;
  }

  const fueraArea = conPlan.filter((caso) => caso.placas > caso.area);
  const cerrados = fueraArea.filter((caso) => caso.placas <= caso.best);

  // Atribucion: que termino alcanza por si solo para cerrar cada caso. Un caso puede
  // contar en varios terminos; `unico` cuenta los que solo cierra ese termino.
  const terminos = ["kerf", "raster", "dff", "proyeccion", "clique"];
  const alcanza = Object.fromEntries(terminos.map((t) => [t, 0]));
  const unico = Object.fromEntries(terminos.map((t) => [t, 0]));
  for (const caso of cerrados) {
    const cubren = terminos.filter((t) => (caso[t] ?? 0) >= caso.placas);
    for (const t of cubren) alcanza[t]++;
    if (cubren.length === 1) unico[cubren[0]]++;
  }
  const msTotal = conPlan.reduce((sum, caso) => sum + (caso.ms ?? 0), 0);
  const msFuera = fueraArea.reduce((sum, caso) => sum + (caso.ms ?? 0), 0);
  const msCerrados = cerrados.reduce((sum, caso) => sum + (caso.ms ?? 0), 0);

  console.log("");
  console.log(`VALOR    fuera de la cota de area: ${fueraArea.length} (${pct(fueraArea.length, conPlan.length)})`);
  console.log(
    `         cerrados por la cota fuerte: ${cerrados.length} (${pct(cerrados.length, fueraArea.length)} de los fuera)`
  );
  console.log(`         siguen fuera: ${fueraArea.length - cerrados.length}`);
  console.log("");
  console.log("ATRIBUCION  termino        alcanza  unico");
  for (const t of terminos) {
    console.log(`            ${t.padEnd(13)} ${String(alcanza[t]).padStart(7)} ${String(unico[t]).padStart(6)}`);
  }
  console.log("");
  console.log(`TIEMPO   total medido: ${msTotal} ms`);
  console.log(`         en casos fuera de cota de area: ${msFuera} ms (${pct(msFuera, msTotal)})`);
  console.log(
    `         en casos que la cota fuerte cierra: ${msCerrados} ms (${pct(msCerrados, msTotal)} del total)`
  );
  console.log("");
  console.log(
    "Nota: el ms de los casos cerrados NO se ahorra entero. La compuerta corta MultiSlice, " +
      "OneBoard y Pattern Master, no el baseline V8 ni la compactacion de franjas, que corren antes."
  );

  const resumen = {
    tag,
    casos: casos.length,
    levanta,
    placasExtra,
    binding,
    conPlan: conPlan.length,
    violaciones: violaciones.length,
    fueraArea: fueraArea.length,
    cerrados: cerrados.length,
    alcanza,
    unico,
    msTotal,
    msFuera,
    msCerrados
  };
  writeFileSync(join(outDir, `summary-${tag}${label === null ? "" : "-" + label}.json`), JSON.stringify(resumen, null, 2));
}

// ---------------------------------------------------------------- utilidades

function pct(part, total) {
  return total > 0 ? ((part / total) * 100).toFixed(1) + "%" : "-";
}

function readJsonl(path) {
  if (!existsSync(path)) return [];
  return readFileSync(path, "utf8")
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (!token.startsWith("--")) {
      out._.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith("--")) out[key] = true;
    else {
      out[key] = next;
      i++;
    }
  }
  return out;
}
