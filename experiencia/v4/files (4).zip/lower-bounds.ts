/* ==========================================================================
   COTAS INFERIORES PARA EL NUMERO DE PLACAS
   ==========================================================================

   Este modulo NO decide nada. Solo calcula un numero N tal que ningun plan
   factible puede usar menos de N placas. Se usa como compuerta: si el plan
   construido ya usa N placas, el plan es OPTIMO en cantidad de placas y toda
   la cadena de rescates (MultiSlice, OneBoard, Pattern Master) es trabajo
   demostrablemente inutil.

   Por que importa: la cota vigente es solo area,

       ceil( SUM area_i / (anchoUtil * altoUtil) )

   que ignora el kerf, la geometria y la restriccion guillotina. En el holdout
   de 2000 casos, 320 no alcanzan esa cota y consumen el 87.6% del tiempo; la
   familia dominante son 222 pedidos que terminan a UNA sola placa de ella.
   Buena parte de esos casos ya son optimos y el motor lo ignora.

   REGLA DE VALIDEZ, no negociable: toda cota de aca tiene que ser <= al
   optimo real para cualquier instancia. Una cota invalida convierte la
   compuerta en una regresion silenciosa. Cada cota lleva abajo su argumento
   de validez y hay tests que la contrastan contra planes factibles reales.

   Todas las cotas dominan a la de area, o sea que `best` nunca queda por
   debajo de lo que devuelve el calculo actual.

   Referencias: Fekete & Schepers (dual feasible functions), Herz (1972) y
   Christofides & Whitlock (1977) (posiciones normales / raster points).
   ========================================================================== */

const EPS = 1e-9;

export interface LowerBoundLine {
  base: number;
  altura: number;
  cant: number;
  veta?: boolean;
  cantos?: { arr?: boolean; aba?: boolean; izq?: boolean; der?: boolean } | null;
}

export interface LowerBoundOptions {
  placaBase: number;
  placaAltura: number;
  refiladoX?: number;
  refiladoY?: number;
  sierra?: number;
  materialConVeta?: boolean;
  descontarCanto?: boolean;
  cantoEspesor?: number;
}

export interface LowerBoundConfig {
  /** Cota por inflado de kerf. Barata, casi siempre util. */
  usarKerf?: boolean;
  /** Cota por funciones dual-factibles. Domina a las de area y kerf. */
  usarDff?: boolean;
  /** Criba de representabilidad sobre el semigrupo de medidas. */
  usarRaster?: boolean;
  /** Cota unidimensional por cruce de la recta media. */
  usarProyeccion?: boolean;
  /** Cota por clique del grafo de incompatibilidad. */
  usarClique?: boolean;
  /** Tope de tipos para armar el grafo de incompatibilidad. */
  maxTiposClique?: number;
  /** Politica de la cascada: piezas maximas para que valga la pena correr la criba. */
  rasterMaxPiezas?: number;
  /** Politica de la cascada: tipos maximos para que valga la pena correr la criba. */
  rasterMaxTipos?: number;
  /** Tope de pares (epsilon, delta) evaluados por eje. */
  maxCandidatosDff?: number;
  /** Tope de celdas de la criba. Por encima se saltea. */
  maxCeldasRaster?: number;
  /** Unidades por milimetro en la criba. 10 = decimas de mm. */
  escalaRaster?: number;
  /** Tope de modulos distintos en la criba. Por encima se saltea. */
  maxModulosRaster?: number;
}

export type LowerBoundSource = "area" | "kerf" | "raster" | "dff" | "proyeccion" | "clique";

export interface LowerBoundResult {
  /** Cota vigente hoy: solo area, sin kerf. */
  area: number;
  /** Cota por inflado de kerf. */
  kerf: number;
  /** Cota por area sobre la placa reducida por la criba de representabilidad. */
  raster: number;
  /** Cota por funciones dual-factibles sobre la placa reducida. */
  dff: number;
  /** Cota unidimensional por cruce de la recta media, maximo de los dos ejes. */
  proyeccion: number;
  /** Cota por clique del grafo de incompatibilidad. */
  clique: number;
  /** Maximo de las anteriores. Es la cota a usar. */
  best: number;
  /** Cual de las cotas quedo activa. */
  binding: LowerBoundSource;
  /** Ancho util antes de la criba. */
  ancho: number;
  /** Alto util antes de la criba. */
  alto: number;
  /** Ancho maximo realmente consumible segun la criba. <= ancho. */
  anchoEfectivo: number;
  /** Alto maximo realmente consumible segun la criba. <= alto. */
  altoEfectivo: number;
  /** La criba corrio de verdad (medidas representables en la escala y bajo topes). */
  rasterAplicado: boolean;
  /** Falso si alguna pieza no entra en la placa en ninguna orientacion. */
  factible: boolean;
}

interface Item {
  /** Ancho de corte, ya descontado el canto si corresponde. */
  w: number;
  /** Alto de corte, ya descontado el canto si corresponde. */
  h: number;
  cant: number;
  /** Si puede girar 90 grados. */
  rota: boolean;
}

const DEFAULTS: Required<LowerBoundConfig> = {
  usarKerf: true,
  usarDff: true,
  usarRaster: true,
  usarProyeccion: true,
  usarClique: true,
  maxCandidatosDff: 24,
  maxTiposClique: 400,
  rasterMaxPiezas: 40,
  rasterMaxTipos: 16,
  maxCeldasRaster: 200_000,
  escalaRaster: 10,
  maxModulosRaster: 512
};

/* --------------------------------------------------------------------------
   Medida de corte. Replica `medidaCorte` de motor.cjs para que la cota mida
   exactamente las piezas que el motor va a colocar y no las nominales.
   -------------------------------------------------------------------------- */
function medidaCorte(line: LowerBoundLine, opts: LowerBoundOptions): { base: number; altura: number } {
  let base = +line.base;
  let altura = +line.altura;
  if (opts.descontarCanto && line.cantos) {
    const e = +(opts.cantoEspesor ?? 0);
    base -= (line.cantos.izq ? e : 0) + (line.cantos.der ? e : 0);
    altura -= (line.cantos.arr ? e : 0) + (line.cantos.aba ? e : 0);
  }
  return { base, altura };
}

/* Orientaciones (a lo largo de X, a lo largo de Y) admisibles dentro de W x H. */
function orientacionesUtiles(item: Item, W: number, H: number): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  if (item.w <= W + EPS && item.h <= H + EPS) out.push([item.w, item.h]);
  if (item.rota && Math.abs(item.w - item.h) > EPS && item.h <= W + EPS && item.w <= H + EPS) {
    out.push([item.h, item.w]);
  }
  return out;
}

/* ==========================================================================
   COTA 1 - AREA (la vigente)
   ========================================================================== */
function cotaArea(items: Item[], W: number, H: number): number {
  const areaTotal = items.reduce((sum, it) => sum + it.cant * it.w * it.h, 0);
  const areaPlaca = W * H;
  if (!(areaPlaca > 0)) return 0;
  return Math.ceil(areaTotal / areaPlaca - EPS);
}

/* ==========================================================================
   COTA 2 - INFLADO POR KERF

   Validez: en cualquier plan factible con sierra s, dos piezas adyacentes
   estan separadas por al menos s sobre el eje del corte que las separa.
   Si a cada pieza le asignamos el rectangulo [x, x+w+s] x [y, y+h+s], esos
   rectangulos son disjuntos (si A esta a la izquierda de B con hueco >= s,
   entonces x_B >= x_A + w_A + s) y estan contenidos en [0, W+s] x [0, H+s]
   porque x + w <= W. Luego el area inflada cabe en la placa inflada y

       N >= ceil( SUM (w_i+s)(h_i+s) / ((W+s)(H+s)) )

   Con s = 4.5 y piezas de 400x300 esto suma ~2.4% de area por pieza, que es
   justo el margen que suele faltar en los pedidos a una placa de la cota.
   ========================================================================== */
function cotaKerf(items: Item[], W: number, H: number, s: number): number {
  if (!(s > 0)) return 0;
  const areaTotal = items.reduce((sum, it) => sum + it.cant * (it.w + s) * (it.h + s), 0);
  const areaPlaca = (W + s) * (H + s);
  if (!(areaPlaca > 0)) return 0;
  return Math.ceil(areaTotal / areaPlaca - EPS);
}

/* ==========================================================================
   COTA 3 - CRIBA DE REPRESENTABILIDAD (semigrupo numerico)

   Por Herz / Christofides-Whitlock, siempre existe un optimo guillotina en
   posiciones "normales": empujando todo hacia el origen, cada extension
   ocupada sobre un eje es una suma de medidas de pieza mas los kerfs
   intermedios. O sea que el largo consumido sobre X pertenece a

       R = { SUM n_j (d_j + s) - s } intersecado [0, W]

   Sea r* el maximo de R. Ninguna placa puede consumir mas de r* sobre X, asi
   que el area realmente utilizable por placa es a lo sumo r* x H, no W x H.
   Idem sobre Y. El resultado se combina con el inflado de kerf sobre la placa
   reducida.

   Se calcula con una criba booleana sobre enteros (decimas de mm por
   defecto). Si alguna medida no es representable exacto en esa escala, la
   criba NO corre: preferimos no aportar cota antes que aportar una invalida
   por redondeo.

   Direcciones seguras: AGRANDAR R siempre es valido (r* sube, la cota baja).
   Por eso se admiten las dos orientaciones de cada pieza sin importar cual
   terminara usando. ACHICAR R seria invalido, asi que nunca se descarta un
   modulo: si hay demasiados, se saltea la criba entera.
   ========================================================================== */
function alcanzableMaximo(
  modulos: Array<{ unidad: number; mult: number }>,
  capacidad: number
): number {
  const reach = new Uint8Array(capacidad + 1);
  reach[0] = 1;
  let maximo = 0;

  for (const { unidad, mult } of modulos) {
    if (unidad <= 0 || unidad > capacidad) continue;
    // Multiplicidad util: nunca entran mas de floor(capacidad / unidad).
    let restante = Math.min(mult, Math.floor(capacidad / unidad));
    // Descomposicion binaria: cubre 0..restante copias con log(restante) pasadas.
    let bloque = 1;
    while (restante > 0) {
      const copias = Math.min(bloque, restante);
      const paso = unidad * copias;
      if (paso <= capacidad) {
        for (let t = capacidad - paso; t >= 0; t--) {
          if (reach[t] && !reach[t + paso]) {
            reach[t + paso] = 1;
            if (t + paso > maximo) maximo = t + paso;
          }
        }
      }
      restante -= copias;
      bloque *= 2;
    }
  }

  return maximo;
}

interface RasterResult {
  aplicado: boolean;
  anchoEfectivo: number;
  altoEfectivo: number;
}

function criba(
  items: Item[],
  W: number,
  H: number,
  s: number,
  cfg: Required<LowerBoundConfig>
): RasterResult {
  const fallback: RasterResult = { aplicado: false, anchoEfectivo: W, altoEfectivo: H };
  if (!cfg.usarRaster) return fallback;

  const escala = cfg.escalaRaster;
  const entero = (x: number): number | null => {
    const v = x * escala;
    const r = Math.round(v);
    return Math.abs(v - r) <= 1e-6 ? r : null;
  };

  const capX = entero(W + s);
  const capY = entero(H + s);
  if (capX === null || capY === null) return fallback;
  if (capX + 1 > cfg.maxCeldasRaster || capY + 1 > cfg.maxCeldasRaster) return fallback;

  // Modulos por eje. Se acumula multiplicidad por medida distinta.
  const modX = new Map<number, number>();
  const modY = new Map<number, number>();
  const sumar = (mapa: Map<number, number>, unidad: number, mult: number) => {
    mapa.set(unidad, (mapa.get(unidad) ?? 0) + mult);
  };

  for (const item of items) {
    const ors = orientacionesUtiles(item, W, H);
    if (!ors.length) return fallback; // instancia no factible: sin cota util
    for (const [a, b] of ors) {
      const ua = entero(a + s);
      const ub = entero(b + s);
      if (ua === null || ub === null) return fallback;
      sumar(modX, ua, item.cant);
      sumar(modY, ub, item.cant);
    }
  }

  if (modX.size > cfg.maxModulosRaster || modY.size > cfg.maxModulosRaster) return fallback;

  const listar = (mapa: Map<number, number>) =>
    [...mapa.entries()]
      .map(([unidad, mult]) => ({ unidad, mult }))
      .sort((a, b) => a.unidad - b.unidad);

  const maxX = alcanzableMaximo(listar(modX), capX);
  const maxY = alcanzableMaximo(listar(modY), capY);
  if (maxX <= 0 || maxY <= 0) return fallback;

  const anchoEfectivo = Math.min(W, maxX / escala - s);
  const altoEfectivo = Math.min(H, maxY / escala - s);
  if (!(anchoEfectivo > 0) || !(altoEfectivo > 0)) return fallback;

  return { aplicado: true, anchoEfectivo, altoEfectivo };
}

/* ==========================================================================
   COTA 4 - FUNCIONES DUAL-FACTIBLES

   Una DFF es u: [0,1] -> [0,1] tal que SUM x_i <= 1 implica SUM u(x_i) <= 1.
   La familia clasica, con epsilon en (0, 1/2]:

       u_e(x) = 1   si x > 1-e
                x   si e <= x <= 1-e
                0   si x < e

   Demostracion: si SUM x_i <= 1, a lo sumo un item supera 1-e (dos sumarian
   mas de 2-2e >= 1). Sin item grande, SUM u = SUM_{x>=e} x <= 1. Con item
   grande, el resto suma menos que e, asi que todos los demas caen bajo el
   umbral y valen 0, y SUM u = 1.

   Con una DFF por eje, la cota es

       N >= ceil( SUM_i u_e(w_i) * u_d(h_i) )

   sobre medidas normalizadas por la placa. Se aplica sobre las dimensiones
   infladas por kerf y sobre la placa ya reducida por la criba, de modo que
   esta cota domina a las tres anteriores: con e = d = 0, u es la identidad y
   se recupera exactamente la cota de area con kerf.

   Con rotacion libre hay que tomar el MINIMO sobre orientaciones, porque la
   orientacion la elige el solver y la relajacion tiene que ser adversarial.

   Solo importan los puntos de quiebre de la familia, o sea los valores
   normalizados y sus complementos. Se los submuestrea de forma
   deterministica: usar un subconjunto de la familia da una cota mas debil,
   nunca invalida.
   ========================================================================== */
function u(x: number, e: number): number {
  if (e <= 0) return x;
  if (x > 1 - e + 1e-12) return 1;
  if (x < e - 1e-12) return 0;
  return x;
}

function candidatos(valores: number[], tope: number): number[] {
  const set = new Set<number>([0, 0.5]);
  for (const v of valores) {
    if (v > 0 && v <= 0.5 + 1e-12) set.add(Math.min(v, 0.5));
    const c = 1 - v;
    if (c > 0 && c <= 0.5 + 1e-12) set.add(Math.min(c, 0.5));
  }
  const orden = [...set].sort((a, b) => a - b);
  if (orden.length <= tope) return orden;

  // Submuestreo equiespaciado conservando extremos. Deterministico.
  const salida: number[] = [];
  for (let i = 0; i < tope; i++) {
    salida.push(orden[Math.round((i * (orden.length - 1)) / (tope - 1))]);
  }
  return [...new Set(salida)];
}

function cotaDff(
  items: Item[],
  W: number,
  H: number,
  s: number,
  tope: number
): number {
  const anchoPlaca = W + s;
  const altoPlaca = H + s;
  if (!(anchoPlaca > 0) || !(altoPlaca > 0)) return 0;

  // Orientaciones normalizadas por pieza, ya infladas por kerf.
  const normalizadas: Array<{ cant: number; ors: Array<[number, number]> }> = [];
  const vx: number[] = [];
  const vy: number[] = [];

  for (const item of items) {
    const ors = orientacionesUtiles(item, W, H).map(([a, b]): [number, number] => [
      (a + s) / anchoPlaca,
      (b + s) / altoPlaca
    ]);
    if (!ors.length) return 0; // no factible: no aportamos cota
    normalizadas.push({ cant: item.cant, ors });
    for (const [x, y] of ors) {
      vx.push(x);
      vy.push(y);
    }
  }

  const es = candidatos(vx, tope);
  const ds = candidatos(vy, tope);

  let mejor = 0;
  for (const e of es) {
    for (const d of ds) {
      let total = 0;
      for (const { cant, ors } of normalizadas) {
        let min = Infinity;
        for (const [x, y] of ors) {
          const val = u(x, e) * u(y, d);
          if (val < min) min = val;
        }
        total += cant * min;
      }
      if (total > mejor) mejor = total;
    }
  }

  return Math.ceil(mejor - EPS);
}

/* ==========================================================================
   COTA 5 - PROYECCION SOBRE UN EJE

   Si TODA orientacion admisible de una pieza tiene alto mayor que H/2,
   entonces en cualquier ubicacion dentro de [0, H] esa pieza cruza la recta
   media y = H/2. Dos piezas asi, en la misma placa, cruzan las dos la misma
   recta, de modo que sus intervalos sobre X son disjuntos y estan separados
   por al menos un kerf. Luego, por placa,

       SUM (w_i + s) <= W + s      sobre las piezas de ese conjunto

   y por lo tanto N >= ceil( SUM (w_i + s) / (W + s) ).

   Se toma el MINIMO ancho entre las orientaciones que califican, porque la
   orientacion la elige el solver.

   Es una cota puramente unidimensional: ve casos que la de area no ve porque
   no le importa cuanta superficie sobra a los costados, solo cuantos frentes
   entran de canto. Simetrica sobre el otro eje.
   ========================================================================== */
function cotaProyeccion(
  items: Item[],
  W: number,
  H: number,
  s: number,
  eje: "x" | "y"
): number {
  const limite = (eje === "x" ? H : W) / 2;
  const capacidad = (eje === "x" ? W : H) + s;
  if (!(capacidad > 0)) return 0;

  let total = 0;
  for (const item of items) {
    const ors = orientacionesUtiles(item, W, H);
    if (!ors.length) return 0;

    // La pieza califica solo si NINGUNA orientacion admisible la deja por
    // debajo de la mitad sobre el eje perpendicular.
    let califica = true;
    let menor = Infinity;
    for (const [a, b] of ors) {
      const perpendicular = eje === "x" ? b : a;
      const paralelo = eje === "x" ? a : b;
      if (perpendicular <= limite + EPS) {
        califica = false;
        break;
      }
      if (paralelo < menor) menor = paralelo;
    }
    if (!califica) continue;

    total += item.cant * (menor + s);
  }

  if (total <= 0) return 0;
  return Math.ceil(total / capacidad - EPS);
}

/* ==========================================================================
   COTA 6 - CLIQUE DE INCOMPATIBILIDAD

   Dos piezas son incompatibles si no existe NINGUN empaque que las ponga en
   la misma placa. Para dos rectangulos el test es exacto y cerrado: cualquier
   empaque de dos rectangulos en un contenedor se normaliza a lado a lado o
   apilado, asi que caben juntas si y solo si existe un par de orientaciones
   con

       a1 + s + a2 <= W  y  max(b1,b2) <= H      (lado a lado)
   o   b1 + s + b2 <= H  y  max(a1,a2) <= W      (apiladas)

   Un conjunto de piezas incompatibles de a pares necesita una placa cada una,
   asi que el tamano de cualquier clique del grafo es una cota inferior.
   Encontrar la clique maxima es NP-duro, pero cualquier clique sirve: una
   busqueda golosa da una cota valida, solo que mas floja.

   Se trabaja a nivel de TIPO, no de pieza. Un tipo incompatible consigo mismo
   aporta sus `cant` unidades a la clique, porque dos copias tampoco pueden
   compartir placa. Un tipo compatible consigo mismo aporta 1.

   Nota: esta cota y la DFF NO se dominan mutuamente. La DFF acumula
   fracciones que la clique no ve; la clique captura conflictos geometricos
   que ninguna funcion separable por eje puede expresar. Por eso van las dos.
   ========================================================================== */
function cabenJuntas(a: Item, b: Item, W: number, H: number, s: number): boolean {
  for (const [a1, b1] of orientacionesUtiles(a, W, H)) {
    for (const [a2, b2] of orientacionesUtiles(b, W, H)) {
      if (a1 + s + a2 <= W + EPS && Math.max(b1, b2) <= H + EPS) return true;
      if (b1 + s + b2 <= H + EPS && Math.max(a1, a2) <= W + EPS) return true;
    }
  }
  return false;
}

function cotaClique(items: Item[], W: number, H: number, s: number, maxTipos: number): number {
  if (items.length > maxTipos) return 0;

  const n = items.length;
  // incompatible[i][j] = true si i y j no pueden compartir placa.
  const incompatible: boolean[][] = [];
  for (let i = 0; i < n; i++) incompatible.push(new Array<boolean>(n).fill(false));
  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      const choque = !cabenJuntas(items[i], items[j], W, H, s);
      incompatible[i][j] = choque;
      incompatible[j][i] = choque;
    }
  }

  // Peso del tipo dentro de una clique: si choca consigo mismo, todas sus
  // unidades necesitan placa propia.
  const peso = items.map((item, i) => (incompatible[i][i] ? item.cant : 1));
  const grado = items.map((_, i) => {
    let g = 0;
    for (let j = 0; j < n; j++) if (j !== i && incompatible[i][j]) g++;
    return g;
  });

  // Dos ordenes golosos distintos. Cualquiera da una cota valida; se toma el
  // mejor de los dos, que sigue siendo valido y suele ser mas ajustado.
  const ordenes = [
    [...items.keys()].sort((a, b) => peso[b] - peso[a] || grado[b] - grado[a] || a - b),
    [...items.keys()].sort((a, b) => grado[b] - grado[a] || peso[b] - peso[a] || a - b)
  ];

  let mejor = 0;
  for (const orden of ordenes) {
    const clique: number[] = [];
    let total = 0;
    for (const i of orden) {
      // Un tipo compatible consigo mismo solo puede entrar con una unidad, y
      // solo si choca con todos los ya elegidos.
      if (clique.some((j) => !incompatible[i][j])) continue;
      clique.push(i);
      total += peso[i];
    }
    if (total > mejor) mejor = total;
  }

  return mejor;
}

/* ==========================================================================
   COMPOSICION
   ========================================================================== */
export function computeLowerBound(
  lineas: LowerBoundLine[],
  opts: LowerBoundOptions,
  config: LowerBoundConfig = {}
): LowerBoundResult {
  const cfg = { ...DEFAULTS, ...config };
  const s = Math.max(0, +(opts.sierra ?? 0));
  const W = +opts.placaBase - +(opts.refiladoX ?? 0);
  const H = +opts.placaAltura - +(opts.refiladoY ?? 0);

  const vacio: LowerBoundResult = {
    area: 0,
    kerf: 0,
    raster: 0,
    dff: 0,
    proyeccion: 0,
    clique: 0,
    best: 0,
    binding: "area",
    ancho: W,
    alto: H,
    anchoEfectivo: W,
    altoEfectivo: H,
    rasterAplicado: false,
    factible: true
  };

  if (!(W > 0) || !(H > 0) || !lineas.length) return vacio;

  const items: Item[] = [];
  for (const linea of lineas) {
    const cant = Math.max(0, Math.floor(+linea.cant));
    if (!cant) continue;
    const { base, altura } = medidaCorte(linea, opts);
    if (!(base > 0) || !(altura > 0)) return vacio;
    items.push({
      w: base,
      h: altura,
      cant,
      rota: !(opts.materialConVeta && linea.veta)
    });
  }
  if (!items.length) return vacio;

  const factible = items.every((item) => orientacionesUtiles(item, W, H).length > 0);
  if (!factible) return { ...vacio, factible: false };

  const area = cotaArea(items, W, H);
  const kerf = cfg.usarKerf ? cotaKerf(items, W, H, s) : 0;

  const raster = criba(items, W, H, s, cfg);
  const Wf = raster.anchoEfectivo;
  const Hf = raster.altoEfectivo;

  // Cota de area con kerf sobre la placa reducida por la criba.
  const cotaRaster = raster.aplicado ? cotaKerf(items, Wf, Hf, s) : 0;

  // La DFF corre sobre la placa reducida, asi que domina a todas las anteriores.
  const dff = cfg.usarDff ? cotaDff(items, Wf, Hf, s, cfg.maxCandidatosDff) : 0;

  // Proyeccion y clique se calculan sobre la placa reducida por la criba.
  const proyeccion = cfg.usarProyeccion
    ? Math.max(cotaProyeccion(items, Wf, Hf, s, "x"), cotaProyeccion(items, Wf, Hf, s, "y"))
    : 0;
  const clique = cfg.usarClique ? cotaClique(items, Wf, Hf, s, cfg.maxTiposClique) : 0;

  let best = area;
  let binding: LowerBoundSource = "area";
  const considerar = (valor: number, fuente: LowerBoundSource) => {
    if (valor > best) {
      best = valor;
      binding = fuente;
    }
  };
  considerar(kerf, "kerf");
  considerar(cotaRaster, "raster");
  considerar(dff, "dff");
  considerar(proyeccion, "proyeccion");
  considerar(clique, "clique");

  return {
    area,
    kerf,
    raster: cotaRaster,
    dff,
    proyeccion,
    clique,
    best,
    binding,
    ancho: W,
    alto: H,
    anchoEfectivo: Wf,
    altoEfectivo: Hf,
    rasterAplicado: raster.aplicado,
    factible: true
  };
}

/** Atajo: solo el numero, para reemplazar el calculo de `cota` en el borde. */
export function strongLowerBound(
  lineas: LowerBoundLine[],
  opts: LowerBoundOptions,
  config?: LowerBoundConfig
): number {
  return computeLowerBound(lineas, opts, config).best;
}

/* ==========================================================================
   CASCADA EN DOS ETAPAS

   Medido sobre 1826 casos historicos consistentes (231 en la familia F1,
   definida como boards40 = areaLB + 1):

       cota          eleva area   certifica F1   costo medio
       area                   0        0/231      0.0028 ms
       kerf                  31       28/231      0.0015 ms
       dff                   70       64/231      0.2905 ms
       raster                47       43/231      1.2499 ms
       proyeccion            51       47/231      0.0039 ms
       clique                44       41/231      0.0304 ms
       todas                 76       70/231      1.5640 ms

   La DFF explica 64 de los 70 certificados y el raster cuesta 4 veces todo lo
   demas junto. Corriendo el raster solo cuando la etapa barata no certifica:
   se ejecuta en 173 de 1826 casos, agrega 6 certificados y cuesta ~2.41 ms
   cuando corre. Son 0.42 s de costo contra 16.2 s de generarPatrones evitado,
   o sea 39x de retorno, pero solo si NO esta en el camino rapido.

   De ahi la cascada: todo lo barato primero, raster solo si hizo falta.

   `incumbente` es la cantidad de placas del plan ya construido. Si la etapa
   barata ya lo certifica, la segunda no aporta nada y no se corre. Sin
   incumbente se corre todo, que es lo correcto cuando se quiere la cota mas
   ajustada y no una decision de compuerta.
   ========================================================================== */
export interface LowerBoundCascadeResult extends LowerBoundResult {
  /** Hasta donde llego la cascada. */
  etapa: "barata" | "completa";
  /** Si la segunda etapa (criba raster) llego a ejecutarse. */
  rasterCorrio: boolean;
  /** La criba se salteo por politica de tamano, no porque la barata certificara. */
  rasterOmitidoPorPolitica: boolean;
  /** Cota de la etapa barata, util para registrar la atribucion. */
  bestBarata: number;
}

export function computeLowerBoundCascade(
  lineas: LowerBoundLine[],
  opts: LowerBoundOptions,
  incumbente?: number,
  config: LowerBoundConfig = {}
): LowerBoundCascadeResult {
  const cfg = { ...DEFAULTS, ...config };
  const barata = computeLowerBound(lineas, opts, { ...config, usarRaster: false });

  // Politica de tamano. Medido sobre la cola F1 pesada (>=20 piezas y >=8 tipos):
  // en el top 50 mas caro la criba agrega 0 certificados y triplica el costo de la
  // cota; sobre los 156 pesados agrega 1 solo certificado y multiplica el costo por
  // 4.7, o sea ~544 ms de computo repartido para ganar un caso. En pedidos chicos y
  // discretizados si rinde. El corte por tamano deja la criba donde paga.
  const piezas = lineas.reduce((total, l) => total + Math.max(0, Math.floor(+l.cant)), 0);
  const tipos = lineas.length;
  const excedeTamano = piezas > cfg.rasterMaxPiezas || tipos > cfg.rasterMaxTipos;

  const certifica = incumbente !== undefined && barata.best >= incumbente;
  if (certifica || config.usarRaster === false || !barata.factible || excedeTamano) {
    return {
      ...barata,
      etapa: "barata",
      rasterCorrio: false,
      rasterOmitidoPorPolitica: excedeTamano && !certifica && config.usarRaster !== false && barata.factible,
      bestBarata: barata.best
    };
  }

  const completa = computeLowerBound(lineas, opts, config);
  // La cascada nunca puede quedar por debajo de la etapa barata: `completa`
  // incluye todos sus terminos y ademas corre sobre la placa reducida.
  return {
    ...completa,
    best: Math.max(completa.best, barata.best),
    etapa: "completa",
    rasterCorrio: completa.rasterAplicado,
    rasterOmitidoPorPolitica: false,
    bestBarata: barata.best
  };
}
